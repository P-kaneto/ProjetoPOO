package repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import connectionFactory.ConnectionFactory;
import model.Usuario;

public class UsuarioDAO {

	private Connection conexao;

	public UsuarioDAO() {
		this.conexao = new ConnectionFactory().getConnection();

	}
	
	//Metodos de tratamento
	public String titleize(String text) {
	    String[] palavras = text.toLowerCase().split(" ");
	    String texto = "";
	    for (int a = 0; a < palavras.length; a++) {
	        String p = palavras[a];
	        palavras[a] = p.substring(0,1).toUpperCase() + p.substring(1);
	        texto = texto + " " + palavras[a];
	    }
	    return texto;
	}
	
	//Metodos banco
	public void adicionaUsuario(Usuario usuario) {
		String sql = "insert into usuario(id, nome, cpf, senha) values (?,?,?,?)";
		try {
			PreparedStatement stmt = conexao.prepareStatement(sql);
			
			stmt.setInt(1, usuario.getId());
			stmt.setString(2, usuario.getNome().toLowerCase());
			stmt.setString(3, usuario.getCpf());
			stmt.setString(4, usuario.getSenha());

			
			stmt.execute();
			stmt.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	
	public List<Usuario> buscaUsuarioNome(String busca) {
		try {
			List<Usuario> usuarios = new ArrayList<Usuario>();
			busca = "%" + busca + "%";
			PreparedStatement stmt = conexao.prepareStatement("select * from usuario where nome like ?");
			stmt.setString(1, busca);
			
			ResultSet rs = stmt.executeQuery();

			while (rs.next()) {
				
				int id = rs.getInt("id");
				String nome = rs.getString("nome");
				nome = titleize(nome);
				String cpf = rs.getString("cpf");
				String senha = rs.getString("senha");
				
				Usuario usuario = new Usuario(id, nome, cpf, senha);
				usuarios.add(usuario);
			}
			rs.close();
			stmt.close();
			return usuarios;
		} catch (SQLException e) {
			System.out.println(e);
			throw new RuntimeException();
		}
	}
	

	public Usuario buscaUsuariosCPF(String busca) {
		try {
			PreparedStatement stmt = conexao.prepareStatement("select * from usuario where cpf=?");
			stmt.setString(1, busca);
			
			ResultSet rs = stmt.executeQuery();
			int id=0;
			String nome="", senha="", cpf="";
			if (rs.next()) {
				id = rs.getInt("id");
				nome = rs.getString("nome");
				nome = titleize(nome);
				cpf = rs.getString("cpf");
				senha = rs.getString("senha");
				
				
			}
			Usuario usuario = new Usuario(id, nome, cpf, senha);
			rs.close();
			stmt.close();
			return usuario;
		} catch (SQLException e) {
			System.out.println(e);
			throw new RuntimeException();
		}
	}
	
	public Usuario buscaUltimoUsuario() {

		try {
			PreparedStatement stmt = conexao.prepareStatement("select * from usuario");
			ResultSet rs = stmt.executeQuery();
			
			int id=0;
			String nome="", senha="", cpf="";
			
			while (rs.next()) {
				
				id = rs.getInt("id");
				nome = rs.getString("nome");
				cpf = rs.getString("cpf");
				senha = rs.getString("senha");
				
			}
			
			Usuario user = new Usuario(id, nome, cpf, senha);
			rs.close();
			stmt.close();
			return user;
		} catch (SQLException e) {
			System.out.println(e);
			throw new RuntimeException();
		}
	}
	
	
	public List<Usuario> buscaTodosUsuarios() {
		try {
			List<Usuario> usuarios = new ArrayList<Usuario>();

			PreparedStatement stmt = conexao.prepareStatement("select * from usuario");
			ResultSet rs = stmt.executeQuery();

			while (rs.next()) {
				
				int id = rs.getInt("id");
				String nome = rs.getString("nome");
				nome = titleize(nome);
				String cpf = rs.getString("cpf");
				String senha = rs.getString("senha");
				
				Usuario usuario = new Usuario(id, nome, cpf, senha);
				usuarios.add(usuario);
			}
			rs.close();
			stmt.close();
			return usuarios;
		} catch (SQLException e) {
			System.out.println(e);
			throw new RuntimeException();
		}
	}

	
	public Usuario buscaUsuarioId(int id) {
		String sql = "select * from usuario where id=?";
		try {
			PreparedStatement stmt = conexao.prepareStatement(sql);
			stmt.setInt(1, id);
			ResultSet rs = stmt.executeQuery();
			String nome="", senha="", cpf="";
			if(rs.next()) {
				nome = rs.getString("nome");
				cpf = rs.getString("cpf");
				senha = rs.getString("senha");

			}
			//nome = titleize(nome);
			Usuario usuario = new Usuario(id, nome, cpf, senha);
			rs.close();
			stmt.close();
			return usuario;
		} catch (SQLException e) {
			System.out.println(e);
			throw new RuntimeException();
		}
	}
	
	public void removeUsuario(int id) {
		String sql = "delete from usuario where id=?";
		try {
			PreparedStatement stmt = conexao.prepareStatement(sql);
			stmt.setInt(1, id);
			stmt.execute();
			stmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void atualizaUsuario(Usuario usuario) {
		String sql = "update usuario set nome=?, cpf=?, senha=? where id=?";

		try {
			PreparedStatement stmt = conexao.prepareStatement(sql);
			stmt.setInt(4, usuario.getId());
			stmt.setString(1, usuario.getNome().toLowerCase());
			stmt.setString(2, usuario.getCpf());
			stmt.setString(3, usuario.getSenha());

			stmt.execute();
			stmt.close();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}

}
