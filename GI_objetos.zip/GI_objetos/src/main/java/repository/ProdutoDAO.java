package repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import connectionFactory.ConnectionFactory;
import model.Produto;
import model.Usuario;

public class ProdutoDAO {
	
	private Connection conexao;

	public ProdutoDAO() {
		this.conexao = new ConnectionFactory().getConnection();

	}
	
	//Metodos de tratamento
	public String titleize(String text) {
	    String[] palavras = text.toLowerCase().split(" ");
	    String texto = "";
	    for (int a = 0; a < palavras.length; a++) {
	        String p = palavras[a];
	        palavras[a] = p.substring(0,1).toUpperCase() + p.substring(1);
	        texto = texto + " " + palavras[a];
	    }
	    return texto;
	}
	
	//Metodos Banco
	public void adicionaProduto(Produto p) {
		String sql = "insert into produto(id, nome, credito) values (?,?,?)";
		try {
			PreparedStatement stmt = conexao.prepareStatement(sql);
			
			stmt.setInt(1, p.getId());
			stmt.setString(2, p.getNome().toLowerCase());
			stmt.setDouble(3, p.getCredito());

			stmt.execute();
			stmt.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	
	public List<Produto> buscaProdutoNome(String busca) {
		try {
			List<Produto> produto = new ArrayList<Produto>();
			busca = "%" + busca + "%";
			PreparedStatement stmt = conexao.prepareStatement("select * from produto where nome like ?");
			stmt.setString(1, busca);
			
			ResultSet rs = stmt.executeQuery();

			while (rs.next()) {
				
				int id = rs.getInt("id");
				String nome = rs.getString("nome");
				nome = titleize(nome);
				double credito = rs.getDouble("credito");

				
				Produto p = new Produto(id, nome, credito);
				produto.add(p);
			}
			rs.close();
			stmt.close();
			return produto;
		} catch (SQLException e) {
			System.out.println(e);
			throw new RuntimeException();
		}
	}
	
	
	public List<Produto> buscaProdutoCredito(double busca) {
		try {
			List<Produto> produto = new ArrayList<Produto>();

			PreparedStatement stmt = conexao.prepareStatement("select * from produto where credito=?");
			stmt.setDouble(1, busca);
			
			ResultSet rs = stmt.executeQuery();

			while (rs.next()) {
				
				int id = rs.getInt("id");
				String nome = rs.getString("nome");
				nome = titleize(nome);
				double credito = rs.getDouble("credito");

				
				Produto p = new Produto(id, nome, credito);
				produto.add(p);
			}
			rs.close();
			stmt.close();
			return produto;
		} catch (SQLException e) {
			System.out.println(e);
			throw new RuntimeException();
		}
	}
	
	
	public Produto buscaUltimoProduto() {

		try {
			PreparedStatement stmt = conexao.prepareStatement("select * from produto");
			ResultSet rs = stmt.executeQuery();
			
			int id=0;
			double credito=0;
			String nome="";
			
			while (rs.next()) {
				
				id = rs.getInt("id");
				nome = rs.getString("nome");
				credito = rs.getDouble("credito");
				
			}
			Produto p = new Produto(id, nome, credito);
			rs.close();
			stmt.close();
			return p;
		} catch (SQLException e) {
			System.out.println(e);
			throw new RuntimeException();
		}
	}
	
	public List<Produto> buscaTodosProdutos() {

		try {
			List<Produto> produto = new ArrayList<Produto>();

			PreparedStatement stmt = conexao.prepareStatement("select * from produto");
			ResultSet rs = stmt.executeQuery();

			while (rs.next()) {
				
				int id = rs.getInt("id");
				String nome = rs.getString("nome");
				nome = titleize(nome);
				double credito = rs.getDouble("credito");

				
				Produto p = new Produto(id, nome, credito);
				produto.add(p);
			}
			rs.close();
			stmt.close();
			return produto;
		} catch (SQLException e) {
			System.out.println(e);
			throw new RuntimeException();
		}
	}

	
	public Produto buscaProdutoId(int id) {
		try {
			PreparedStatement stmt = conexao.prepareStatement("select * from produto where id=?");
			stmt.setInt(1, id);
			
			ResultSet rs = stmt.executeQuery();
			String nome="";
			double credito=0;
			if(rs.next()) {
				nome = rs.getString("nome");
				credito = rs.getDouble("credito");
			}
			//nome = titleize(nome);
			Produto p = new Produto(id, nome, credito);
			rs.close();
			stmt.close();
			return p;
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	
	
	public void removeProduto(int id) {
		String sql = "delete from produto where id=?";
		try {
			PreparedStatement stmt = conexao.prepareStatement(sql);
			stmt.setInt(1, id);
			stmt.execute();
			stmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void atualizaProduto(Produto p) {
		String sql = "update produto set nome=?, credito=? where id=?";

		try {
			PreparedStatement stmt = conexao.prepareStatement(sql);
			stmt.setInt(3, p.getId());
			stmt.setString(1, p.getNome().toLowerCase());
			stmt.setDouble(2, p.getCredito());
			

			stmt.execute();
			stmt.close();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
	
}
