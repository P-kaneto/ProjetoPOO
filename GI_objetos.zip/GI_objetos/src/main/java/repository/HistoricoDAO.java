package repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import connectionFactory.ConnectionFactory;
import model.Historico;
import model.Produto;
import model.Usuario;

public class HistoricoDAO {
	
	private Connection conexao;

	public HistoricoDAO() {
		this.conexao = new ConnectionFactory().getConnection();

	}
	
	//Metodos banco
	public void adicionaHistorico(Historico historico) {
		String sql = "insert into historico(id, credito, peso_lixo, peso_plastico, peso_vidro, peso_metal, peso_papel, id_usuario) values (?,?,?,?,?,?,?,?)";
		try {
			PreparedStatement stmt = conexao.prepareStatement(sql);
			
			stmt.setInt(1, historico.getId());
			stmt.setDouble(2, historico.getCredito());
			stmt.setDouble(3, historico.getPeso_lixo());
			stmt.setDouble(4, historico.getPeso_plastico());
			stmt.setDouble(5, historico.getPeso_vidro());
			stmt.setDouble(6, historico.getPeso_metal());
			stmt.setDouble(7, historico.getPeso_papel());
			stmt.setInt(8, historico.getId_usuario());

			stmt.execute();
			stmt.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public Historico buscaUltimoHistorico() {

		try {
			PreparedStatement stmt = conexao.prepareStatement("select * from historico");
			ResultSet rs = stmt.executeQuery();
			
			int id=0, id_usuario=0;
			double credito=0, peso_lixo=0, peso_plastico=0, peso_vidro=0, peso_metal=0, peso_papel=0;
			
			while (rs.next()) {
				id = rs.getInt("id");
				credito = rs.getInt("credito");
				peso_lixo = rs.getDouble("peso_lixo");
				peso_plastico = rs.getDouble("peso_plastico");
				peso_vidro = rs.getDouble("peso_vidro");
				peso_metal = rs.getDouble("peso_metal");
				peso_papel = rs.getDouble("peso_papel");
				id_usuario = rs.getInt("id_usuario");
			}
			
			Historico historico = new Historico(id, credito, peso_lixo, peso_plastico, peso_vidro, peso_metal, peso_papel, id_usuario);
			rs.close();
			stmt.close();
			return historico;
		} catch (SQLException e) {
			System.out.println(e);
			throw new RuntimeException();
		}
	}
	
	
	public List<Historico> buscaHistoricoPeso(double busca) {
		try {
			List<Historico> hist = new ArrayList<Historico>();

			PreparedStatement stmt = conexao.prepareStatement("select * from historico where peso_lixo=?");
			stmt.setDouble(1, busca);
			
			ResultSet rs = stmt.executeQuery();

			while (rs.next()) {
				
				int id = rs.getInt("id");
				double credito = rs.getDouble("credito");
				double peso_lixo = rs.getDouble("peso_lixo");
				double peso_plastico = rs.getDouble("peso_plastico");
				double peso_vidro = rs.getDouble("peso_vidro");
				double peso_metal = rs.getDouble("peso_metal");
				double peso_papel = rs.getDouble("peso_papel");
				int id_usuario = rs.getInt("id_usuario");
				
				Historico historico = new Historico(id, credito, peso_lixo, peso_plastico, peso_vidro, peso_metal, peso_papel, id_usuario);
				hist.add(historico);
			}
			rs.close();
			stmt.close();
			return hist;
		} catch (SQLException e) {
			System.out.println(e);
			throw new RuntimeException();
		}
	}
	
	
	public List<Historico> buscaHistoricoCredito(double busca) {
		try {
			List<Historico> hist = new ArrayList<Historico>();

			PreparedStatement stmt = conexao.prepareStatement("select * from historico where credito=?");
			stmt.setDouble(1, busca);
			
			ResultSet rs = stmt.executeQuery();

			while (rs.next()) {
				
				int id = rs.getInt("id");
				double credito = rs.getDouble("credito");
				double peso_lixo = rs.getDouble("peso_lixo");
				double peso_plastico = rs.getDouble("peso_plastico");
				double peso_vidro = rs.getDouble("peso_vidro");
				double peso_metal = rs.getDouble("peso_metal");
				double peso_papel = rs.getDouble("peso_papel");
				int id_usuario = rs.getInt("id_usuario");
				
				Historico historico = new Historico(id, credito, peso_lixo, peso_plastico, peso_vidro, peso_metal, peso_papel, id_usuario);
				hist.add(historico);
			}
			rs.close();
			stmt.close();
			return hist;
		} catch (SQLException e) {
			System.out.println(e);
			throw new RuntimeException();
		}
	}
	

	public List<Historico> buscaTodosHistorico() {

		try {
			List<Historico> hist = new ArrayList<Historico>();

			PreparedStatement stmt = conexao.prepareStatement("select * from historico");
			ResultSet rs = stmt.executeQuery();

			while (rs.next()) {
				
				int id = rs.getInt("id");
				double credito = rs.getDouble("credito");
				double peso_lixo = rs.getDouble("peso_lixo");
				double peso_plastico = rs.getDouble("peso_plastico");
				double peso_vidro = rs.getDouble("peso_vidro");
				double peso_metal = rs.getDouble("peso_metal");
				double peso_papel = rs.getDouble("peso_papel");
				int id_usuario = rs.getInt("id_usuario");
				
				Historico historico = new Historico(id, credito, peso_lixo, peso_plastico, peso_vidro, peso_metal, peso_papel, id_usuario);
				hist.add(historico);
			}
			rs.close();
			stmt.close();
			return hist;
		} catch (SQLException e) {
			System.out.println(e);
			throw new RuntimeException();
		}
	}
	
	
	public Historico buscaHistoricoIdUsuario(int id_user) {
		try {
			PreparedStatement stmt = conexao.prepareStatement("select * from historico where id_usuario=?");
			stmt.setInt(1, id_user);
			ResultSet rs = stmt.executeQuery();
			int id_usuario=0;
			double credito=0, peso_lixo=0, peso_plastico=0, peso_vidro=0, peso_metal=0, peso_papel=0;
			if(rs.next()) {
				credito = rs.getDouble("credito");
				peso_lixo = rs.getDouble("peso_lixo");
				peso_plastico = rs.getDouble("peso_plastico");
				peso_vidro = rs.getDouble("peso_vidro");
				peso_metal = rs.getDouble("peso_metal");
				peso_papel = rs.getDouble("peso_papel");
				id_usuario = rs.getInt("id_usuario");
			}
			
			
			Historico historico = new Historico(id_user, credito, peso_lixo, peso_plastico, peso_vidro, peso_metal, peso_papel, id_usuario);
			rs.close();
			stmt.close();
			return historico;
			

			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	
	public Historico buscaHistoricoId(int id) {
		try {
			PreparedStatement stmt = conexao.prepareStatement("select * from historico where id=?");
			stmt.setInt(1, id);
			ResultSet rs = stmt.executeQuery();
			int id_usuario=0;
			double credito=0, peso_lixo=0, peso_plastico=0, peso_vidro=0, peso_metal=0, peso_papel=0;
			if(rs.next()) {
				credito = rs.getDouble("credito");
				peso_lixo = rs.getDouble("peso_lixo");
				peso_plastico = rs.getDouble("peso_plastico");
				peso_vidro = rs.getDouble("peso_vidro");
				peso_metal = rs.getDouble("peso_metal");
				peso_papel = rs.getDouble("peso_papel");
				id_usuario = rs.getInt("id_usuario");
			}
			
			
			Historico historico = new Historico(id, credito, peso_lixo, peso_plastico, peso_vidro, peso_metal, peso_papel, id_usuario);
			rs.close();
			stmt.close();
			return historico;
			

			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	public void removeHistorico(int id) {
		String sql = "delete from historico where id=?";
		try {
			PreparedStatement stmt = conexao.prepareStatement(sql);
			stmt.setInt(1, id);
			stmt.execute();
			stmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void atualizaHistorico(Historico hist) {
		String sql = "update historico set credito=?, peso_lixo=?, peso_plastico=?, peso_vidro=?, peso_metal=?, peso_papel=?, id_usuario=? where id=?";

		try {
			PreparedStatement stmt = conexao.prepareStatement(sql);

			stmt.setDouble(1, hist.getCredito());
			stmt.setDouble(2, hist.getPeso_lixo());
			stmt.setDouble(3, hist.getPeso_plastico());
			stmt.setDouble(4, hist.getPeso_vidro());
			stmt.setDouble(5, hist.getPeso_metal());
			stmt.setDouble(6, hist.getPeso_papel());
			stmt.setInt(7, hist.getId_usuario());
			stmt.setInt(8, hist.getId());

			stmt.execute();
			stmt.close();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
	
}
