package model;

public class Historico {
	
	private int id; 
	private double credito;
	private double peso_lixo;
	private double peso_plastico;
	private double peso_vidro;
	private double peso_metal;
	private double peso_papel;
	private int id_usuario;
	
	public Historico(int id, double credito, double peso_lixo, double peso_plastico, double peso_vidro,
			double peso_metal, double peso_papel, int id_usuario) {
		super();
		this.id = id;
		this.credito = credito;
		this.peso_lixo = peso_lixo;
		this.peso_plastico = peso_plastico;
		this.peso_vidro = peso_vidro;
		this.peso_metal = peso_metal;
		this.peso_papel = peso_papel;
		this.id_usuario = id_usuario;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public double getCredito() {
		return credito;
	}

	public void setCredito(double credito) {
		this.credito = credito;
	}

	public double getPeso_lixo() {
		return peso_lixo;
	}

	public void setPeso_lixo(double peso_lixo) {
		this.peso_lixo = peso_lixo;
	}

	public double getPeso_plastico() {
		return peso_plastico;
	}

	public void setPeso_plastico(double peso_plastico) {
		this.peso_plastico = peso_plastico;
	}

	public double getPeso_vidro() {
		return peso_vidro;
	}

	public void setPeso_vidro(double peso_vidro) {
		this.peso_vidro = peso_vidro;
	}

	public double getPeso_metal() {
		return peso_metal;
	}

	public void setPeso_metal(double peso_metal) {
		this.peso_metal = peso_metal;
	}

	public double getPeso_papel() {
		return peso_papel;
	}

	public void setPeso_papel(double peso_papel) {
		this.peso_papel = peso_papel;
	}
	
	public int getId_usuario() {
		return id_usuario;
	}

	public void setId_usuario(int id_usuario) {
		this.id_usuario = id_usuario;
	}
	
}
