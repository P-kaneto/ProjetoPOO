package control;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Historico;
import repository.HistoricoDAO;
import repository.UsuarioDAO;

/**
 * Servlet implementation class removeUsuario
 */
@WebServlet("/removeUsuario")
public class removeUsuarioServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		int id = Integer.parseInt(req.getParameter("id"));
		
		UsuarioDAO dao = new UsuarioDAO();
		HistoricoDAO dao2 = new HistoricoDAO();
		
		List<Historico> historico = dao2.buscaTodosHistorico();
	      for(Historico hist : historico ) {
	    	  if(hist.getId_usuario() == id) {
	    		  dao2.removeHistorico(hist.getId());
	    		  break;
	    	  }
	       }
		
		dao.removeUsuario(id);
		
		resp.sendRedirect("listaUsuarios");
	}

}
