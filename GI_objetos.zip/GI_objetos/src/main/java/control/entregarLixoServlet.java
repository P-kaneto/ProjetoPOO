package control;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Historico;
import model.Usuario;
import repository.HistoricoDAO;
import repository.UsuarioDAO;

@WebServlet("/entregarLixo")
public class entregarLixoServlet extends HttpServlet{
	private static final long serialVersionUID = 1L;
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		HistoricoDAO dao = new HistoricoDAO();
		UsuarioDAO dao2 = new UsuarioDAO();
		String cpf = req.getParameter("cpf");
		
		double peso = Double.parseDouble(req.getParameter("peso"));
		String tipo = req.getParameter("tipo");
		Usuario user = dao2.buscaUsuariosCPF(cpf);
		int id_usuario = user.getId();
		Historico hist = dao.buscaHistoricoIdUsuario(id_usuario);
		
		int id = hist.getId();
		double credito = hist.getCredito();
		double peso_lixo = hist.getPeso_lixo();
		double peso_plastico = hist.getPeso_plastico();
		double peso_vidro = hist.getPeso_vidro();
		double peso_metal = hist.getPeso_metal();
		double peso_papel = hist.getPeso_papel();
		
		
		peso_lixo += peso;
		if(tipo.equals("plastico")) {
			credito += 0.95 * peso;
			peso_plastico += peso;
		}else if(tipo.equals("vidro")) {
			credito += 1.05 * peso;
			peso_vidro += peso;
		}else if(tipo.equals("metal")) {
			credito += 3.5 * peso;
			peso_metal += peso;
		}else if(tipo.equals("papel")) {
			credito += 0.6 * peso;
			peso_papel += peso;
		}
		
		Historico historico = new Historico (id, credito, peso_lixo, peso_plastico, peso_vidro, peso_metal, peso_papel, id_usuario);
		dao.atualizaHistorico(historico);
		
		
		RequestDispatcher rd = req.getRequestDispatcher("/entregarLixo.jsp");
		rd.forward(req, resp);
	}
}
