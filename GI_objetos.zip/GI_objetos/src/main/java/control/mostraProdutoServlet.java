package control;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Produto;
import repository.ProdutoDAO;

/**
 * Servlet implementation class mostraTransporteServlet
 */
@WebServlet("/mostraProduto")
public class mostraProdutoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		int id = Integer.parseInt(req.getParameter("id"));
		ProdutoDAO dao = new ProdutoDAO();
		
		Produto p = dao.buscaProdutoId(id);
		req.setAttribute("produto", p);
		RequestDispatcher rd = req.getRequestDispatcher("/formAlteraProduto.jsp");
		rd.forward(req, resp);
		
	}

}

