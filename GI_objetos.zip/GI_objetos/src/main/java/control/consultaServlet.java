package control;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Usuario;
import repository.HistoricoDAO;
import repository.UsuarioDAO;

@WebServlet("/consulta")
public class consultaServlet extends HttpServlet{
	private static final long serialVersionUID = 1L;
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		HistoricoDAO dao = new HistoricoDAO();
		UsuarioDAO dao2 = new UsuarioDAO();
		String busca = req.getParameter("busca");
		Usuario user = dao2.buscaUsuariosCPF(busca);
		int id = user.getId();
		
		//Se usar o if(busca != null || !busca.isEmpty()) n�o ir� funcionar
		if(busca == null || busca.isEmpty()) {
			
		}else{
			req.setAttribute("historico", dao.buscaHistoricoIdUsuario(id));
		}
		
		
		RequestDispatcher rd = req.getRequestDispatcher("/consulta.jsp");
		rd.forward(req, resp);
	}
}
