package control;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import repository.HistoricoDAO;

/**
 * Servlet implementation class listaEstabelecimentos
 */
@WebServlet("/listaHistoricos")
public class listaHistoricosServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		HistoricoDAO dao = new HistoricoDAO();
		String busca = req.getParameter("busca");
		String tipo_busca = req.getParameter("tipo_busca");
		boolean existe_busca = false;
		
		if(busca == null || busca.isEmpty()) {
			req.setAttribute("historicos", dao.buscaTodosHistorico());
		}else {
			double busc = Double.parseDouble(busca);
			existe_busca = true;
			if(tipo_busca.equals("credito")) {
				req.setAttribute("historicos", dao.buscaHistoricoCredito(busc));
			}else if(tipo_busca.equals("peso")) {
				req.setAttribute("historicos", dao.buscaHistoricoPeso(busc));
			}
		}
		
		req.setAttribute("validacao", existe_busca);
		
		RequestDispatcher rd = req.getRequestDispatcher("/listaHistoricos.jsp");
		rd.forward(req, resp);
	}

}
