package control;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Usuario;
import repository.UsuarioDAO;

/**
 * Servlet implementation class alteraUsuario
 */
@WebServlet("/alteraUsuario")
public class alteraUsuarioServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	@Override
		protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

			String nome = req.getParameter("nome");
			String cpf = req.getParameter("cpf");
			String senha = req.getParameter("senha");
			int id = Integer.parseInt(req.getParameter("id"));
			
			UsuarioDAO dao = new UsuarioDAO();
			
			Usuario usuario = dao.buscaUsuarioId(id);
			usuario.setId(id);
			usuario.setNome(nome);
			usuario.setCpf(cpf);
			usuario.setSenha(senha);
			dao.atualizaUsuario(usuario);
			resp.sendRedirect("listaUsuarios");
			
		
		}

}
