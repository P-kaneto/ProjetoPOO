package control;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Usuario;
import repository.UsuarioDAO;

@WebServlet("/listaUsuarios")
public class listaUsuariosServlet extends HttpServlet{

	private static final long serialVersionUID = 1L;

	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		UsuarioDAO dao = new UsuarioDAO();
		String busca = req.getParameter("busca");
		String tipo_busca = req.getParameter("tipo_busca");
		boolean cpf = false;
		boolean existe_busca = false;
		
		if(busca == null || busca.isEmpty()) {
			req.setAttribute("usuarios", dao.buscaTodosUsuarios());
			req.setAttribute("tipo", cpf);
		}else {
			existe_busca = true;
			if(tipo_busca.equals("nome_busca")) {
				busca.toLowerCase();
				req.setAttribute("tipo", cpf);
				req.setAttribute("usuarios", dao.buscaUsuarioNome(busca));
			}else if(tipo_busca.equals("cpf_busca")) {
				req.setAttribute("usuario", dao.buscaUsuariosCPF(busca));
				cpf = true;
				req.setAttribute("tipo", cpf);
			}
		}
		req.setAttribute("validacao", existe_busca);
		
		RequestDispatcher rd = req.getRequestDispatcher("/listaUsuarios.jsp");
		rd.forward(req, resp);
	}
}
