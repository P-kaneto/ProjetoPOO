package control;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import repository.ProdutoDAO;

/**
 * Servlet implementation class listaTransporteServlet
 */
@WebServlet("/listaProdutos")
public class listaProdutosServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		ProdutoDAO dao = new ProdutoDAO();
		String busca = req.getParameter("busca");
		String tipo_busca = req.getParameter("tipo_busca");
		boolean existe_busca = false;

		if(busca == null || busca.isEmpty()) {
			req.setAttribute("produtos", dao.buscaTodosProdutos());
		}else {
			existe_busca = true;
			if(tipo_busca.equals("credito")) {
				req.setAttribute("produtos", dao.buscaProdutoCredito(Integer.parseInt(busca)));
			}else if(tipo_busca.equals("nome")) {
				busca.toLowerCase();
				req.setAttribute("produtos", dao.buscaProdutoNome(busca));
			}
		}
		req.setAttribute("validacao", existe_busca);
		
		RequestDispatcher rd = req.getRequestDispatcher("/listaProdutos.jsp");
		rd.forward(req, resp);
	}

}
