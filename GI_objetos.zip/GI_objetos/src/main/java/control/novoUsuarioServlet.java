package control;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Usuario;
import repository.UsuarioDAO;

@WebServlet("/novoUsuario")
public class novoUsuarioServlet extends HttpServlet{
	private static final long serialVersionUID = 1L;
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		UsuarioDAO dao = new UsuarioDAO();
		Usuario user = dao.buscaUltimoUsuario();
		
		int id = user.getId()+1;
		String nome = req.getParameter("nome");
		String cpf = req.getParameter("cpf");
		String senha = req.getParameter("senha");
		
		Usuario usuario = new Usuario(id, nome, cpf, senha);
		
		dao.adicionaUsuario(usuario);
		
		req.setAttribute("usuario", usuario);
		resp.sendRedirect("listaUsuarios");
		
	}
}
