package control;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Historico;
import model.Usuario;
import repository.HistoricoDAO;
import repository.UsuarioDAO;

@WebServlet("/adicionaHistorico")
public class adicionaHistoricoServlet extends HttpServlet{
	private static final long serialVersionUID = 1L;
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		UsuarioDAO dao = new UsuarioDAO();
		HistoricoDAO dao2 = new HistoricoDAO();
		
		List<Usuario> usuarios = new ArrayList<Usuario>();
		
		for(Usuario user: dao.buscaTodosUsuarios()) {
			boolean verificacao = false;
			for(Historico hist: dao2.buscaTodosHistorico()) {
				if(user.getId() == hist.getId_usuario()) {
					verificacao = true;
					break;
				}	
			}
			
			if(verificacao == false) {
				usuarios.add(user);
			}
			
		}
		
		req.setAttribute("usuarios", usuarios);
		RequestDispatcher rd = req.getRequestDispatcher("/formNovoHistorico.jsp");
		rd.forward(req, resp);
	}
}
