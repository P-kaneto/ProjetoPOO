package control;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Historico;
import model.Produto;
import model.Usuario;
import repository.HistoricoDAO;
import repository.ProdutoDAO;
import repository.UsuarioDAO;

@WebServlet("/resgatarProduto")
public class resgatarProdutoServlet extends HttpServlet{
	private static final long serialVersionUID = 1L;
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		HistoricoDAO dao = new HistoricoDAO();
		UsuarioDAO dao2 = new UsuarioDAO();
		ProdutoDAO dao3 = new ProdutoDAO();
		
		boolean credito_negativo = false;
		boolean resgate = false;
		
		//resgate campos forms
		String cpf = req.getParameter("cpf");
		int id_produto = Integer.parseInt(req.getParameter("produto"));
		
		//armazendo nas variaveis as buscas no banco
		Usuario user = dao2.buscaUsuariosCPF(cpf);
		int id_usuario = user.getId();
		Historico hist = dao.buscaHistoricoIdUsuario(id_usuario);
		Produto p = dao3.buscaProdutoId(id_produto);
		
		//vari�veis objeto Historico
		int id = hist.getId();
		double credito = hist.getCredito();
		double peso_lixo = hist.getPeso_lixo();
		double peso_plastico = hist.getPeso_plastico();
		double peso_vidro = hist.getPeso_vidro();
		double peso_metal = hist.getPeso_metal();
		double peso_papel = hist.getPeso_papel();
		if(credito - p.getCredito()<0) {
			credito_negativo = true;
			req.setAttribute("negativo", credito_negativo);
		}else {
			resgate = true;
			credito -= p.getCredito();
		}
		req.setAttribute("resgate", resgate);
		
		
		Historico historico = new Historico (id, credito, peso_lixo, peso_plastico, peso_vidro, peso_metal, peso_papel, id_usuario);
		dao.atualizaHistorico(historico);
		
		req.setAttribute("produtos", dao3.buscaTodosProdutos());
		
		RequestDispatcher rd = req.getRequestDispatcher("/resgatarProduto.jsp");
		rd.forward(req, resp);
	}
}
