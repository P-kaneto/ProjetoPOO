package control;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Historico;
import repository.HistoricoDAO;

@WebServlet("/novoHistorico")
public class novoHistoricoServlet extends HttpServlet{
	private static final long serialVersionUID = 1L;
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		HistoricoDAO dao = new HistoricoDAO();
		Historico hist = dao.buscaUltimoHistorico();
		
		int id = hist.getId()+1;
		double credito=0, peso_lixo=0, peso_plastico=0, peso_vidro=0, peso_metal=0, peso_papel=0;
		int id_usuario = Integer.parseInt(req.getParameter("cpf"));
		
		Historico historico = new Historico(id, credito, peso_lixo, peso_plastico, peso_vidro, peso_metal, peso_papel, id_usuario);
		
		dao.adicionaHistorico(historico);
		
		req.setAttribute("historico", historico);
		resp.sendRedirect("listaHistoricos");
		
	}
}
