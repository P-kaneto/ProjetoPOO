package control;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Historico;
import repository.HistoricoDAO;

/**
 * Servlet implementation class alteraTransporteServlet
 */
@WebServlet("/alteraHistorico")
public class alteraHistoricoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		int id = Integer.parseInt(req.getParameter("id"));
		double credito = Double.parseDouble(req.getParameter("credito"));
		double peso_lixo = Double.parseDouble(req.getParameter("peso_lixo"));
		double peso_plastico = Double.parseDouble(req.getParameter("peso_plastico"));
		double peso_vidro = Double.parseDouble(req.getParameter("peso_vidro"));
		double peso_metal = Double.parseDouble(req.getParameter("peso_metal"));
		double peso_papel = Double.parseDouble(req.getParameter("peso_papel"));
		int id_usuario = Integer.parseInt(req.getParameter("id_usuario"));
		
		
		HistoricoDAO dao = new HistoricoDAO();
		
		Historico h = dao.buscaHistoricoId(id);
		h.setId(id);
		h.setCredito(credito);
		h.setPeso_lixo(peso_lixo);
		h.setPeso_plastico(peso_plastico);
		h.setPeso_vidro(peso_vidro);
		h.setPeso_metal(peso_metal);
		h.setPeso_papel(peso_papel);
		h.setPeso_papel(peso_papel);
		h.setId_usuario(id_usuario);
		dao.atualizaHistorico(h);
		
		resp.sendRedirect("listaHistoricos");
		
	
	}

}
