package control;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Produto;
import repository.ProdutoDAO;



@WebServlet("/novoProduto")
public class novoProdutoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		ProdutoDAO dao = new ProdutoDAO();
		Produto p2 = dao.buscaUltimoProduto();
		
		int id = p2.getId()+1;
		String nome = req.getParameter("nome");
		double credito = Double.parseDouble(req.getParameter("credito"));
		
		Produto p = new Produto(id, nome, credito);
		
		dao.adicionaProduto(p);
		
		req.setAttribute("produto", p);
		resp.sendRedirect("listaProdutos");
		
	}

}
